/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package l5;

/**
 *
 * @author michaelmanzella
 */
public class Queue <T>{
    
    private Node head;
    private Node tail;
    private int size;
    
    public Queue()
    {head = null;
    tail=null;
    size=0;
    }
    
    
    public void enqueue( T item) {
      
        Node temp=new Node(item);
        if (head==null)
      { 
          head=temp;
          tail=temp;
                  }
        else{
            tail.next=temp;
            temp.prev=tail;
            tail=temp;
        }
        size++;   }
        
  public T dequeue() {
      Node temp=head;
      if(size>1)
      {
      head=head.next;
      head.prev=null;
      temp.next=null;
      }
       
      size--;
      return (T)temp.item;
   }
   public boolean isEmpty() {
      if(size==0)return true;
      else return false;
   }
   public int size() {
      return size;
   }
   public void deQueueAll() {
     head=tail=null;
     size=0;
   }
   public T peek()
   {   
            
     return (T)head.item;
       
   } 
}

